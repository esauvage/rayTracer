#ifndef MATERIAL_H
#define MATERIAL_H

#include "point3D.h"

#include <string>

using namespace std;

class Material
{
public:
	string name;
	Point3D col;
	float reflectance;
};

#endif // MATERIAL_H