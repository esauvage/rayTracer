#include "horizon.h"

Horizon::Horizon(float hauteur)
	:_hauteur(hauteur)
{
}

float Horizon::distance(const Point3D& origin, const Point3D& direction) const
{
	return (_hauteur-origin.z)/direction.z;
}

Point3D Horizon::normal(const Point3D& p) const
{
	return Point3D(0, 0, 1);
}
