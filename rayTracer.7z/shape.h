#ifndef SHAPE
#define SHAPE

#include "point3D.h"
#include "material.h"

class Shape
{
public:
// 	Shape();
	virtual float distance(const Point3D & origin, const Point3D & direction) const = 0;
	virtual Point3D normal(const Point3D & p) const = 0;
	Material material;
};
#endif // SHAPE