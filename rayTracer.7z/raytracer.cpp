#include "raytracer.h"

#include <iostream>
#include <thread>
#include <functional>
#include <cmath>

float frand() {return rand()/(float)RAND_MAX;}

RayTracer::RayTracer()
{
}

RayTracer::~RayTracer()
{
}

void RayTracer::generateFile(const string &outFile)
{
	scene.create();
	const int width {800};
	const int height {600};
	
	FILE * outF = fopen("test.ppm", "w");
	fprintf(outF, "P6 %d %d 255 ", (int)width, (int)height); // The PPM Header is issued
	const float halfAngle {tan(M_PI/6.)};
	const float coef { halfAngle*2./max<float>(width, height)};
	for (float i {height}, x { -height/2.*coef}; i--; x+=coef)
	{
		for (float j = 0, y = -width/2.*coef; j < width; ++j, y+=coef)
		{
			const Point3D point(0, 0, 1);
			Point3D pixel;
			const int antiAliasing {8};
			for (auto k = 0; k < antiAliasing; k++)
			{
				const Point3D rayon = Point3D(1, -y + (frand() - 0.5) * coef, 
									-x + (frand() - 0.5) * coef).norm();
				pixel = pixel + pixelColor(point, rayon) * (1. / antiAliasing);
			}
			pixel = pixel * 255;
			fprintf(outF, "%c%c%c", (int)pixel.x, (int)pixel.y, (int)pixel.z);
		}
	}
}

Point3D RayTracer::pixelColor(const Point3D &point, const Point3D &rayon, const Shape * origine)
{
	auto p = nearestShape(point, rayon, origine);
	const float minDist = p.first;
	Shape * minShape = p.second;
	if (!minShape)
	{
		return Point3D{0, 0, 0};
	}
	const Point3D impact = point + rayon * minDist;
	const Point3D normale = minShape->normal(impact);
	const Point3D reflexion = rayon - normale * (rayon % normale) * 2;
	Point3D couleur(0, 0, 0);
	for (auto l:scene.lights)
	{
		float coef {0};
		const int softShadow{8};
 		for (int k = 0; k < softShadow; k++)
 		{
			const Point3D lPos = (l->pos + (Point3D(frand() - 0.5, frand() - 0.5, frand() - 0.5) * 0.1)).norm();
			p = nearestShape(impact, lPos, minShape);
			if (p.second)
			{
				continue;
			}
			Point3D RLight = lPos - normale * (lPos % normale) * 2;
			coef += max<float>(lPos % normale, 0); // Partie diffusion
			const auto dot = max<float>(0., rayon % RLight);
			coef += pow(dot, 20) * 0.2; //Partie spéculaire
		}
		couleur = couleur + minShape->material.col * (1./255.) * l->col * coef * (1./(float)softShadow);
	}
	couleur = couleur * (1./scene.lights.size());
	if (minShape->material.reflectance)
		couleur = couleur + pixelColor(impact, reflexion, minShape) * minShape->material.reflectance;
	return couleur.borne({1,1,1});
// 	return (couleur * (1./scene.lights.size()) + recursion * minShape->material.reflectance).borne(Point3D(1, 1, 1));
}

pair<float, Shape *> RayTracer::nearestShape(const Point3D& origin, const Point3D& direction, const Shape * excluded) const
{
	float minDist = -1;
	Shape * minShape = nullptr;
	for (Shape * o:scene.shapes)
	{
		float d = o->distance(origin, direction);
		if (d <= 0)
			continue;
		if ((((d < minDist)) || (minDist < 0)) && (o != excluded))
		{
			minShape = move(o);
			minDist = d;
		}
	}
	return pair<float, Shape *> {minDist, minShape};
}
