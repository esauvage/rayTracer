#ifndef SCENE_H
#define SCENE_H

#include <vector>

#include "shape.h"
#include "light.h"

using namespace std;

class Scene
{
public:
	~Scene();
	vector <Shape *> shapes;
	vector <Light *> lights;
	void create();
	bool load();
};

#endif