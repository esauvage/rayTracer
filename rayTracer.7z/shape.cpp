#include "shape.h"

// Shape::Shape()
// {
// }