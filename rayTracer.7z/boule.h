#ifndef BOULE_H
#define BOULE_H

#include "shape.h"

class Boule : public Shape
{
public:
	Boule(const Point3D& position, float rayon);
	virtual float distance(const Point3D & origin, const Point3D & direction) const;
	virtual Point3D normal(const Point3D & p) const;
private:
	Point3D _pos;
	float _r;
};

#endif // BOULE_H
