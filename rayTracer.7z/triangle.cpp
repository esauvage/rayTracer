#include "triangle.h"

Triangle::Triangle(const array <Point3D, 3> &points)
	:_p(points), _n(((_p[0] - _p[1])^(_p[2] - _p[1])).norm()), _e1{_p[1] - _p[0]}, _e2{_p[2] - _p[0]}
{
}

float Triangle::distance(const Point3D & origin, const Point3D & direction) const
{
	const Point3D h {direction ^ _e2};
	const float a = _e1 % h;

	if (a > -0.00001 && a < 0.00001)
		return -1;

	const float f = 1. / a;
	const Point3D s {origin - _p[0]};
	
	const float u = (s % h) * f;

	if (u < 0.0 || u > 1.0)
		return -1;

	const Point3D q {s ^ _e1};
	const float v = f * (direction % q);

	if (v < 0.0 || u + v > 1.0)
		return -1;
	
	return f * (_e2 % q);
}

Point3D Triangle::normal(const Point3D & p) const
{
	return _n;
}
