#ifndef HORIZON_H
#define HORIZON_H

#include "shape.h"

class Horizon : public Shape
{
public:
	Horizon(float hauteur);
	virtual float distance(const Point3D & origin, const Point3D & direction) const;
	virtual Point3D normal(const Point3D & p) const;
private:
	float _hauteur;
};

#endif // HORIZON_H