#ifndef PARSER_H
#define PARSER_H

#include "shape.h"
#include "tokenStream.h"
#include <map>
#include <vector>

using namespace std;

class Parser
{
public:
	Parser (istream &is):_ts(is){};
	vector <Shape *> prim(bool get);
private:
	void error(const string& s);

	Token_stream _ts;
	map <string, float> params();
	int _nbErrors {0};
};

#endif //PARSER_H