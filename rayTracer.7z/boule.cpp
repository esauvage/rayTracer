#include "boule.h"

Boule::Boule(const Point3D& position, float rayon)
	:_pos{position}, _r{rayon}
{
}

float Boule::distance(const Point3D& origin, const Point3D& direction) const
{
	Point3D p(origin - _pos);
	const auto b = (p % direction);
	const auto c = (p % p - _r * _r);
	const auto q = b * b - c;
	if (q >= 0)
	{
		const auto sqrtQ = sqrt(q);
		const float r1 = -b-sqrtQ;
		const float r2 = -b+sqrtQ;
		return (r2 > 0 && r2 < r1) ? r2 : r1;
	}
	return -1;
}

Point3D Boule::normal(const Point3D& p) const
{
	return (p - _pos).norm();
}
