#include "point3D.h"

#include <algorithm>

using namespace std;

Point3D::Point3D(float a, float b, float c)
	:x(a), y(b), z(c)
{
}

Point3D Point3D::borne(const Point3D &maxP)
{
	x = min(x, maxP.x);
	y = min(y, maxP.y);
	z = min(z, maxP.z);
	return *this;
}
