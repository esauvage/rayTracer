#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "shape.h"

#include <array>

class Triangle : public Shape 
{
public:
	Triangle(const array< Point3D, int(3) >& points);
	virtual float distance(const Point3D & origin, const Point3D & direction) const;
	virtual Point3D normal(const Point3D & p) const;
private:
	array< Point3D, 3 > _p;
	Point3D _n;
	Point3D _e1;
	Point3D _e2;
};

#endif //TRIANGLE_H