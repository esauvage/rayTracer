#include "raytracer.h"

#include <map>

map <string, string> arguments(int argc, char *argv[])
{
	map <string, string> res;
	for (auto i = argc; i--;)
	{
		string k {*argv++};
		string v {(!(i-1) || *argv[0] == '-') ? "" :*argv++};
//		res.insert(k, v);
//		res.push_back(*argv++);
	}
	return res;
}

int main(int argc, char *argv[])
{
	auto args = arguments(argc, argv);
	RayTracer rayTracer;
	rayTracer.generateFile("");
	return 0;
}
