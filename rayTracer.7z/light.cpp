#include "light.h"

Light::Light(const Point3D& position, const Point3D& couleur)
	:pos(position), col(couleur * (1./255.))
{
}
