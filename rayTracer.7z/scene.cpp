#include "scene.h"

#include "triangle.h"

#include <fstream>
#include <iostream>
#include "parser.h"

template <typename T>
void deleteElems(vector <T *> scene)
{
	for (auto i:scene)
	{
		delete i;
	}
}

void Scene::create()
{
	if (!load())
		cout << "Bad file : standard scene generated." << endl;
// 	Material mMur {"mur", Point3D{250, 250, 255}, 0.};
// 	array<Point3D, 3> t{Point3D(-1, 2, 5), Point3D(5, 2, 5), Point3D(5, 2, -1)};
// 	shapes.push_back(new Triangle(t));
// 	(*shapes.rbegin())->material = mMur;
// 	t = {Point3D(-1, 2, 5), Point3D(5, 2, -1), Point3D(-1, 2, -1)};
// 	shapes.push_back(new Triangle(t));
// 	(*shapes.rbegin())->material = mMur;
// 	t = {Point3D(5, 2, 5), Point3D(5, -3, 5), Point3D(5, 2, -1)};
// 	shapes.push_back(new Triangle(t));
// 	(*shapes.rbegin())->material = mMur;
// 	t = {Point3D(5, -3, 5), Point3D(5, -3, -1), Point3D(5, 2, -1)};
// 	shapes.push_back(new Triangle(t));
// 	(*shapes.rbegin())->material = mMur;
// 	t = {Point3D(-1, 2, 5), Point3D(-1, -3, 5), Point3D(-1, -3, -1)};
// 	shapes.push_back(new Triangle(t));
// 	(*shapes.rbegin())->material = mMur;
// 	t = {Point3D(-1, -3, -1), Point3D(-1, 2, -1), Point3D(-1, 2, 5)};
// 	shapes.push_back(new Triangle(t));
// 	(*shapes.rbegin())->material = mMur;
// 	t = {Point3D(-1, -3, -1), Point3D(-1, -3, 5), Point3D(5, -3, 5)};
// 	shapes.push_back(new Triangle(t));
// 	(*shapes.rbegin())->material = mMur;
// 	t = {Point3D(5, -3, 5), Point3D(5, -3, -1), Point3D(-1, -3, -1)};
// 	shapes.push_back(new Triangle(t));
// 	(*shapes.rbegin())->material = mMur;
	lights.push_back(new Light(Point3D(-0.1, -1, 1).norm(), {128, 128, 128}));
	lights.push_back(new Light(Point3D(-1, -0.1, 1).norm(), {255, 255, 255}));
}

Scene::~Scene()
{
	deleteElems<Shape>(shapes);
	deleteElems<Light>(lights);
}

bool Scene::load()
{
	ifstream ifs("scene.txt");
	if (!ifs.good())
		return false;
	Parser parser(ifs);
	shapes = parser.prim(true);
	ifs.close();
	return !shapes.empty();
}
