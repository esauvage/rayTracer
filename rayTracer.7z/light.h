#ifndef LIGHT_H
#define LIGHT_H

#include "point3D.h"

class  Light
{
public:
	Light(const Point3D &position, const Point3D &couleur);
	Point3D pos;
	Point3D col;
};

#endif //LIGHT_H