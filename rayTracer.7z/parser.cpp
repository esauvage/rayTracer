#include "parser.h"

#include <iostream>
#include <map>
#include <exception>

#include "tokenStream.h"
#include "boule.h"
#include "horizon.h"
#include "triangle.h"

vector <Shape *> Parser::prim(bool get)
{
	Material m[3] {{"rouge", Point3D{250, 50, 20}, 0.4}, {"vert", Point3D{50, 100, 250}, 0.4}, 
					{"bleu", Point3D{250, 250, 0}, 0.4}};
	Material mHorizon {"sol", Point3D{80, 50, 10}, 0.2};
	Material mMur {"mur", Point3D{150, 200, 255}, 0.};
	vector <Shape *> shapes;
	while (true)
	{
		if (get) 
			_ts.get();
		switch (_ts.current().kind)
		{
			case Kind::end :
			case Kind::group :
				return shapes;// c'est un séparateur, tout va bien
			default:
				if (_ts.current().kind != Kind::type)
				{
					error("Name of a primitive expected");
					return shapes;
				}
		}
		auto primitive = _ts.current().string_value;
		auto parameters = params();
		if (primitive == "sphere")
		{
			shapes.push_back(new Boule({parameters["x"], parameters["y"], parameters["z"]}, parameters["radius"]));
			(*shapes.rbegin())->material = m[shapes.size()%3];
		}
		if (primitive == "horizon")
		{
			shapes.push_back(new Horizon(parameters["elevation"]));
			(*shapes.rbegin())->material = mHorizon;
		}
		if (primitive == "triangle")
		{
			array<Point3D, 3> t{Point3D(parameters["x0"], parameters["y0"], parameters["z0"]), 
				Point3D(parameters["x1"], parameters["y1"], parameters["z1"]), 
				Point3D(parameters["x2"], parameters["y2"], parameters["z2"])};
			shapes.push_back(new Triangle(t));
			(*shapes.rbegin())->material = mMur;
		}
	}
	return shapes;
}

map< string, float > Parser::params()
{
	map< string, float > p;
	while (true)
	{
		_ts.get();
		switch (_ts.current().kind)
		{
			case Kind::sep :
			case Kind::end :
			case Kind::group :
				return p;// c'est un séparateur, tout va bien
			default:
				if (_ts.current().kind != Kind::type)
				{
					error("Name of a parameter expected");
					return p;//
				}
		}
		string key = _ts.current().string_value;
		_ts.get();
		if (_ts.current().kind != Kind::number)
		{
			error("Value of a parameter expected");
			return p;//
		}
		p.insert({key, _ts.current().number_value});
	}
	return p;
}

void Parser::error(const string &s)
{
	_nbErrors++;
	cerr << "error : " << s << endl;
	throw std::runtime_error(s);
}
