#ifndef RAY_TRACER_H
#define RAY_TRACER_H

#include "scene.h"

class RayTracer
{
public:
	RayTracer();
	~RayTracer();
	void generateFile(const string& outFile);
private:
	pair<float, Shape *> nearestShape(const Point3D& origin, const Point3D& direction, 
									  const Shape *excluded) const;
	Point3D pixelColor(const Point3D& point, const Point3D& rayon, const Shape* origine = nullptr);
	Scene scene;
};

#endif // RAY_TRACER_H
