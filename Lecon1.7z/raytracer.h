#ifndef RAY_TRACER
#define RAY_TRACER

#include "point3D.h"

class RayTracer
{
public:
	RayTracer();
	void generateFile();
private:
	bool testBoule(const Point3D & origin, const Point3D & direction);
	bool testHorizon(const Point3D & origin, const Point3D & direction);
};

#endif // RAY_TRACER
