#include "point3D.h"

Point3D::Point3D(float a, float b, float c)
	:x(a), y(b), z(c)
{
}
