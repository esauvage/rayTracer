#include "raytracer.h"

#include <iostream>

using namespace std;

RayTracer::RayTracer()
{
}

bool RayTracer::testBoule(const Point3D & origin, const Point3D & direction)
{
	Point3D pos(60, 10, 5);
	Point3D p(origin - pos);
	auto b = 2*(p % direction);
	auto c = 4*(p % p - 4);
	auto q = b * b - c;
	return q >= 0;
}

bool RayTracer::testHorizon(const Point3D & origin, const Point3D & direction)
{
	if (direction.z < 0)
		return true;
	return false;
}

void RayTracer::generateFile()
{
	auto width = 200;
	auto height = 200;
	auto z = -100;
	auto y = -100;
	cout << "P6 " << width << " " << height << " 255 "; // The PPM Header is issued
	for (auto i = z; i < z + height; ++i)
	{
		for (auto j = y; j < y + width; ++j)
		{
			Point3D point(0, j*0.2, i*0.2);
			Point3D pixel;
			for (auto k = -8; k < 8; ++k)
			{
				Point3D rayon = Point3D(30, -j*0.2, -i*0.2+k*0.02).norm();
				if (testBoule(point, rayon))
				{
					pixel.x += 8;
					pixel.y += 15;
					pixel.z += 8;
				}
				else if (testHorizon(point, rayon))
				{
					pixel.x += 15;
					pixel.y += 8;
					pixel.z += 15;
				}
			}
			printf("%c%c%c", (int)pixel.x, (int)pixel.y, (int)pixel.z);
		}
	}
}
