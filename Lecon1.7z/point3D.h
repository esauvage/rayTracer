#ifndef POINT_3D
#define POINT_3D

#include <math.h>

class Point3D
{
public:
	float x, y, z;  // Vector has three float attributes.
	Point3D operator+(const Point3D &r) const {return Point3D(x+r.x, y+r.y, z+r.z);} //Vector add
	Point3D operator-(const Point3D &r) const {return Point3D(x-r.x, y-r.y, z-r.z);} //Vector sub
	Point3D operator*(float r){return Point3D(x*r,y*r,z*r);}       //Vector scaling
	auto operator % (Point3D r)->decltype(x)
	{
		return x * r.x + y * r.y + z * r.z;
	}    //Vector dot product
	Point3D operator^(Point3D r){return Point3D(y*r.z-z*r.y,z*r.x-x*r.z,x*r.y-y*r.x);} //Cross-product
    Point3D(float a = 0., float b = 0., float c = 0.);
    Point3D norm(){return *this*(1 /sqrt(*this%*this));} // Used later for normalizing the vector
};

#endif //POINT_3D
