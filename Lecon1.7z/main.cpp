#include "raytracer.h"
//~ 
//~ #include <iostream>
//~ 
//~ using namespace std;

int main()
{
	RayTracer rayTracer;
	rayTracer.generateFile();
	return 0;
}
